﻿Imports System.Data.SqlClient

Module GlobalModule
    ' Connection string to the SQL Server database
    Public connectionString As String = "Server=AcerA315\SQLEXPRESS;Database=soundrentalsystemdb;Trusted_Connection=True;"

    ' Function to open a connection
    Public Function GetConnection() As SqlConnection
        Dim conn As New SqlConnection(connectionString)
        Try
            conn.Open()
            Return conn
        Catch ex As Exception
            MessageBox.Show("Database connection failed: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return Nothing
        End Try
    End Function
End Module