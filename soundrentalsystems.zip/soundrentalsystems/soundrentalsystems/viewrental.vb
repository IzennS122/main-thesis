﻿Imports System.Data.SqlClient

Public Class ViewRentalForm
    ' Declare the DataGridView and ComboBox at the form level
    Private DataGridViewEquipment As New DataGridView()
    Friend WithEvents cmbEquipmentType As ComboBox

    ' Load equipment data based on the selected type
    Private Sub LoadEquipmentData(Optional equipmentType As String = "")
        ' Build the query to fetch equipment based on type
        Dim query As String = "SELECT * FROM equipments"
        If Not String.IsNullOrEmpty(equipmentType) Then
            query &= " WHERE type = @type"
        End If

        ' Connect to the database and execute the query
        Using conn As SqlConnection = GetConnection()
            If conn IsNot Nothing Then
                Using cmd As New SqlCommand(query, conn)
                    If Not String.IsNullOrEmpty(equipmentType) Then
                        cmd.Parameters.AddWithValue("@type", equipmentType)
                    End If

                    ' Fill the DataGridView with data
                    Dim adapter As New SqlDataAdapter(cmd)
                    Dim table As New DataTable()
                    adapter.Fill(table)
                    DataGridViewEquipment.DataSource = table
                End Using
            End If
        End Using
    End Sub

    ' Form load event
    Private Sub ViewRentalForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Initialize the ComboBox
        cmbEquipmentType = New ComboBox()
        cmbEquipmentType.Items.Add("Speaker")
        cmbEquipmentType.Items.Add("Mic")
        cmbEquipmentType.Items.Add("Lights")
        cmbEquipmentType.Items.Add("All Equipment") ' Option to view all
        cmbEquipmentType.SelectedItem = "All Equipment" ' Default selection

        ' Add ComboBox to the form
        cmbEquipmentType.Dock = DockStyle.Top
        Me.Controls.Add(cmbEquipmentType)

        ' Initialize the DataGridView
        DataGridViewEquipment.Dock = DockStyle.Fill
        Me.Controls.Add(DataGridViewEquipment)

        ' Load all equipment data initially
        LoadEquipmentData()

        ' Bind event for ComboBox selection change
        AddHandler cmbEquipmentType.SelectedIndexChanged, AddressOf cmbEquipmentType_SelectedIndexChanged
    End Sub

    ' Handle ComboBox selection change event
    Private Sub cmbEquipmentType_SelectedIndexChanged(sender As Object, e As EventArgs)
        Dim selectedType As String = cmbEquipmentType.SelectedItem.ToString()
        If selectedType = "All Equipment" Then
            LoadEquipmentData() ' Load all equipment if "All Equipment" is selected
        Else
            LoadEquipmentData(selectedType) ' Load equipment of the selected type
        End If
    End Sub
End Class
