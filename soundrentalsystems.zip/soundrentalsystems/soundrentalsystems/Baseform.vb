﻿Imports System.Data.SqlClient

Public Class Baseform
    ' Method to load forms into the MainContentPanel
    Private Sub LoadForm(form As Form)
        ' Clear the main content panel
        MainContentPanel.Controls.Clear()

        ' Configure and load the new form
        form.TopLevel = False
        form.FormBorderStyle = FormBorderStyle.None
        form.Dock = DockStyle.Fill
        MainContentPanel.Controls.Add(form)
        form.Show()
    End Sub

    ' Event handlers for each button
    Private Sub btnviewrental_Click(sender As Object, e As EventArgs) Handles btnviewrental.Click
        Dim viewRentalsForm As New ViewRentalForm()
        LoadForm(viewRentalsForm)
    End Sub

    Private Sub btninventory_Click(sender As Object, e As EventArgs) Handles btninventory.Click
        Dim inventoryForm As New inventory()
        LoadForm(inventoryForm)
    End Sub

    Private Sub btnadddrental_Click(sender As Object, e As EventArgs) Handles btnaddrental.Click
        Dim addRentalsForm As New addrental()
        LoadForm(addRentalsForm)
    End Sub

    Private Sub btnrecents_Click(sender As Object, e As EventArgs) Handles btnrecents.Click
        Dim recentForm As New Recents()
        LoadForm(recentForm)
    End Sub

    Private Sub btnupcoming_Click(sender As Object, e As EventArgs) Handles btnupcoming.Click
        Dim upcomingForm As New upcoming()
        LoadForm(upcomingForm)
    End Sub

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnlogout.Click
        ' Close the application or redirect to the login form
        Me.Close()
    End Sub

    Private Sub btnTestConnection_Click(sender As Object, e As EventArgs)

    End Sub
End Class
