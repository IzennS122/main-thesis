﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Baseform
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Baseform))
        Me.Menupanel = New System.Windows.Forms.Panel()
        Me.btnlogout = New System.Windows.Forms.Button()
        Me.btninventory = New System.Windows.Forms.Button()
        Me.btnaddrental = New System.Windows.Forms.Button()
        Me.btnviewrental = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MainContentPanel = New System.Windows.Forms.Panel()
        Me.btnrecents = New System.Windows.Forms.Button()
        Me.btnupcoming = New System.Windows.Forms.Button()
        Me.Menupanel.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Menupanel
        '
        Me.Menupanel.Controls.Add(Me.btnupcoming)
        Me.Menupanel.Controls.Add(Me.btnrecents)
        Me.Menupanel.Controls.Add(Me.btnlogout)
        Me.Menupanel.Controls.Add(Me.btninventory)
        Me.Menupanel.Controls.Add(Me.btnaddrental)
        Me.Menupanel.Controls.Add(Me.btnviewrental)
        Me.Menupanel.Controls.Add(Me.PictureBox1)
        Me.Menupanel.Dock = System.Windows.Forms.DockStyle.Left
        Me.Menupanel.Location = New System.Drawing.Point(0, 0)
        Me.Menupanel.Name = "Menupanel"
        Me.Menupanel.Size = New System.Drawing.Size(253, 777)
        Me.Menupanel.TabIndex = 0
        '
        'btnlogout
        '
        Me.btnlogout.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnlogout.Location = New System.Drawing.Point(0, 700)
        Me.btnlogout.Name = "btnlogout"
        Me.btnlogout.Size = New System.Drawing.Size(253, 77)
        Me.btnlogout.TabIndex = 5
        Me.btnlogout.Text = "Logout"
        Me.btnlogout.UseVisualStyleBackColor = True
        '
        'btninventory
        '
        Me.btninventory.Dock = System.Windows.Forms.DockStyle.Top
        Me.btninventory.Location = New System.Drawing.Point(0, 368)
        Me.btninventory.Name = "btninventory"
        Me.btninventory.Size = New System.Drawing.Size(253, 77)
        Me.btninventory.TabIndex = 4
        Me.btninventory.Text = "Inventory"
        Me.btninventory.UseVisualStyleBackColor = True
        '
        'btnaddrental
        '
        Me.btnaddrental.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnaddrental.Location = New System.Drawing.Point(0, 291)
        Me.btnaddrental.Name = "btnaddrental"
        Me.btnaddrental.Size = New System.Drawing.Size(253, 77)
        Me.btnaddrental.TabIndex = 2
        Me.btnaddrental.Text = "Add Rental"
        Me.btnaddrental.UseVisualStyleBackColor = True
        '
        'btnviewrental
        '
        Me.btnviewrental.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnviewrental.Location = New System.Drawing.Point(0, 214)
        Me.btnviewrental.Name = "btnviewrental"
        Me.btnviewrental.Size = New System.Drawing.Size(253, 77)
        Me.btnviewrental.TabIndex = 1
        Me.btnviewrental.Text = "View Rental"
        Me.btnviewrental.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(253, 214)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'MainContentPanel
        '
        Me.MainContentPanel.Location = New System.Drawing.Point(326, 54)
        Me.MainContentPanel.Name = "MainContentPanel"
        Me.MainContentPanel.Size = New System.Drawing.Size(1037, 676)
        Me.MainContentPanel.TabIndex = 1
        '
        'btnrecents
        '
        Me.btnrecents.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnrecents.Location = New System.Drawing.Point(0, 445)
        Me.btnrecents.Name = "btnrecents"
        Me.btnrecents.Size = New System.Drawing.Size(253, 77)
        Me.btnrecents.TabIndex = 6
        Me.btnrecents.Text = "Recents"
        Me.btnrecents.UseVisualStyleBackColor = True
        '
        'btnupcoming
        '
        Me.btnupcoming.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnupcoming.Location = New System.Drawing.Point(0, 522)
        Me.btnupcoming.Name = "btnupcoming"
        Me.btnupcoming.Size = New System.Drawing.Size(253, 77)
        Me.btnupcoming.TabIndex = 7
        Me.btnupcoming.Text = "Upcoming"
        Me.btnupcoming.UseVisualStyleBackColor = True
        '
        'Baseform
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1448, 777)
        Me.Controls.Add(Me.MainContentPanel)
        Me.Controls.Add(Me.Menupanel)
        Me.Name = "Baseform"
        Me.Text = "Form1"
        Me.Menupanel.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Menupanel As Panel
    Friend WithEvents btninventory As Button
    Friend WithEvents btnaddrental As Button
    Friend WithEvents btnviewrental As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnlogout As Button
    Friend WithEvents MainContentPanel As Panel
    Friend WithEvents btnupcoming As Button
    Friend WithEvents btnrecents As Button
End Class
